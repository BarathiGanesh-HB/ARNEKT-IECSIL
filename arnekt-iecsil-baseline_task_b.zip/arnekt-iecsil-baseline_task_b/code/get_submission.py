import os
from load_data import get_test_data
from load_data import get_train_data
from sklearn.naive_bayes import MultinomialNB
from sklearn.feature_extraction.text import CountVectorizer


# tamil - ta, malayalam - ml, telugu = te, kannada - kn, hindi - hi
lang_code = 'ta'


# getting root directories
train_root_dir = '../data/arnekt-iecsil-ie-corpus_train/task_b/'
test_root_dir = '../data/arnekt-iecsil-ie-corpus_test_1/task_b/'

# getting train file paths
train_path = os.path.join(train_root_dir, 'v1_train.' + lang_code)


# getting test1 file paths
test1_path = os.path.join(test_root_dir, 'v1_test1.'  + lang_code)

# loading data
train_texts, train_labels = get_train_data(train_path)
test_texts = get_test_data(test1_path)


# representing data
vectorizer = CountVectorizer()
train_matrix = vectorizer.fit_transform(train_texts)
test_matrix = vectorizer.transform(test_texts)

# classification model
clf = MultinomialNB()
clf.fit(train_matrix, train_labels)

test_results = clf.predict(test_matrix).tolist()

# predicting label for test texts
write_file = open('../submission/v1_test1_tagged.' + lang_code, 'w')
for text in test_results:
    write_file.write(text + '\n')
write_file.close()
