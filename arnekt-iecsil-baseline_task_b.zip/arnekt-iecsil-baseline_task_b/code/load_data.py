
def get_train_data(path):
    texts = []
    labels = []
    read_file = open(path, 'r')
    for line in read_file:
        line = line.replace('\n','')
        if line == 'newline':
            pass
        else:
            items = line.split('\t')
            texts.append(items[0])
            labels.append(items[1])
    read_file.close()

    return texts, labels


def get_test_data(path):
    texts = []
    read_file = open(path, 'r')
    for line in read_file:
        line = line.replace('\n','')
        texts.append(line)  
    read_file.close()
    return texts
