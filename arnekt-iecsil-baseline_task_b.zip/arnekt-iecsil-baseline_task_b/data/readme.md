# once you run the sh download_files.sh, the training and testing will be downloaded and unzipped in this folder
