cd data/
wget https://github.com/BarathiGanesh-HB/ARNEKT-IECSIL/raw/master/arnekt-iecsil-ie-corpus_train.zip
unzip arnekt-iecsil-ie-corpus_train.zip
wget https://github.com/BarathiGanesh-HB/ARNEKT-IECSIL/raw/master/arnekt-iecsil-ie-corpus_test_1.zip
unzip arnekt-iecsil-ie-corpus_test_1.zip
